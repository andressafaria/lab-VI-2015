<html>
<head>
	<meta charset="UTF-8">
	<title>Sistema de FAQ</title>
	
	<link type="text/css" rel="stylesheet" href="require/css/style.css">
	<script type="text/javascript" src="require/js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="require/js/login.js"></script>
	<script type="text/javascript" src="../require/js/faq.js"></script>
	
</head>
<body>
	
	<div id="dvBase">
		<header>
		
		</header>
		
		<main>