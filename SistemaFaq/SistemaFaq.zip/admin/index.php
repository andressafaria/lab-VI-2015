<?php require_once '../header.php';?>

<p>Painel administrativo</p>

<button onclick="btnInserir()">Inseir JS</button>


<?php require_once '../footer.php';?>