function btnInserir(){
	//alert('testando');
	window.location.href='inserir.php';
}