<?php

	class Faq{
		
		public function listFaq(){
			
		}
		
	}

?>